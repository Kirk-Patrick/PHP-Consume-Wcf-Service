﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace AppWcfServiceHub
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IMembershipService" in both code and config file together.
    [ServiceContract]
    public interface IMembershipService
    {
        [OperationContract]
        string getMessage();  //definition of get message method
    }
}
